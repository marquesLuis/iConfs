//
//  CalendarDayViewController.h
//  Demo
//
//  Created by Devin Ross on 3/16/13.
//
//

#import <TapkuLibrary/TapkuLibrary.h>
#import <UIKit/UIKit.h>

@interface CalendarDayViewController : TKCalendarDayViewController

@property (nonatomic,strong) NSArray *data;

@end
