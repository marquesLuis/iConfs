//
//  SlideToUnlockViewController.h
//  Demo
//
//  Created by Devin Ross on 5/21/13.
//
//

#import <UIKit/UIKit.h>

@interface SlideToUnlockViewController : TKViewController

@property (nonatomic,strong) TKSlideToUnlockView *unlockView;

@end
